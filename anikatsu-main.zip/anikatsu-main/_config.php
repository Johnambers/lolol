<?php 

$websiteTitle = "AniKatsu"; // Website Name
$websiteUrl = "//{$_SERVER['SERVER_NAME']}";  // Website URL
$websiteLogo = "/files/images/logo.png"; // Logo
$contactEmail = "xyz@gmail.com"; // Contact Email


//Donate 
$donate = "https://www.buymeacoffee.com/shashankk";

// Socials 
$telegram = "https://t.me/anikatsu"; // telegram
$discord = "https://discord.com/invite/FrWnWRrZmk"; // Discord
$redit = "#"; // Reddit
$twitter = "#"; // Twitter
 


$disqus = "https://random-co6vnxqche.disqus.com"; // Disqus


// API URL
$api = "https://266f7b13-4867-4ef5-bd86-b25dc799681b.id.repl.co"; // https://replit.com/@shashankktiwari/anikatsu


$banner = $websiteUrl . "/files/images/banner.png";  //Banner
?>
